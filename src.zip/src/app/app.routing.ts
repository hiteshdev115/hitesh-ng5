// routerConfig.ts
import { ModuleWithProviders }  from '@angular/core';
import { Routes,RouterModule } from '@angular/router';

export const appRoutes: Routes = [
    { path: '', loadChildren: 'app/front/layout.module#LayoutsModule' }
];

export const rootRouting: ModuleWithProviders = RouterModule.forRoot(appRoutes,{ enableTracing: true });