import { NgModule }       from '@angular/core';
import { CommonModule }   from '@angular/common';

import { HomeComponent }     from './components/home.component';
import { HeaderComponent }     from './components/header.component';
import { FooterComponent }     from './components/footer.component';
import { LayoutRoute } from './layout.route';
import {RouterModule} from '@angular/router';

@NgModule({
  imports: [
    CommonModule,
    LayoutRoute
  ],
  declarations: [
    HomeComponent,
    HeaderComponent,
    FooterComponent
  ],
  providers: [
  ],
  exports:[]
})
export class LayoutsModule {
  constructor(){
  }
}