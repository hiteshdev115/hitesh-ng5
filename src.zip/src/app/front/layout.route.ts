import { ModuleWithProviders }   from '@angular/core';
import { Routes, RouterModule }  from '@angular/router';

import {HomeComponent} from './components/home.component';

export const LayoutRoutes: Routes = [
  {
    path: '',
    component: HomeComponent
    // canActivate: [AuthGuard],
  }
];

export const LayoutRoute: ModuleWithProviders = RouterModule.forChild(LayoutRoutes);