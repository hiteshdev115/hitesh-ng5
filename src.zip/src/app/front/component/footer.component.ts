import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: '../view/footer.component.html'
})
export class FooterComponent {
  constructor() {
	    console.log('footer');
	}
}
