import { Observable, Subject, pipe } from 'rxjs';
import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import {Router, RouterOutlet} from '@angular/router';

//import { AuthService } from './../../auth/auth.service';


@Component({
  selector: 'app-header',
  templateUrl: '../view/header.component.html'
})
export class HeaderComponent {
	constructor() {
	    console.log('header');
	}
  
}
