import { Component } from '@angular/core';
import {Router, RouterOutlet} from '@angular/router';

@Component({
	selector: 'app-home',
  	templateUrl: '../view/home.component.html'
 })
export class HomeComponent {
	constructor() {
		console.log('Home Component');
	}
}
